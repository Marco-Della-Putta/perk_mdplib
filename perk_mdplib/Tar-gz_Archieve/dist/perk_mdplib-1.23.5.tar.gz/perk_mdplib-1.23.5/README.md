Mdp Private Class(c). All rights reserved.
Contact me for details. --- marcodp183@gmail.com ---
This is Library for learning the arts of the Class and improving knowledge.
Also there are some usefully mathematics function like Expression().linear(self, coeffxx, coeffyy, term), for
resolving simple Linear Systems.
Some built_in types like Floating Points, Integer, and String are 'overloaded'. This don't create any problem with
working with the prestabilied built_in types.
This Library is under GNU License. For details read the GNU License clauses starting this Library from itself.
GNU License imposes that the developer of the Library must be reported at the top of the it.
Do not remove or modify this clauses during the distribution of this.
For any details visit https://grigoprg.webnode.it

Read The LICENSE.txt before sharing the __MdpLibrary__.
Marco Della Putta, ITALY(c). All rights Reserved.
Do not share the Library without the Releated Files

